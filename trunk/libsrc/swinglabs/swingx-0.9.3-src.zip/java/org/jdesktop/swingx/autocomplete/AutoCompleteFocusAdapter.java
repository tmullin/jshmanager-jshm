/**
 * 
 */
package org.jdesktop.swingx.autocomplete;

import java.awt.event.FocusAdapter;

/**
 * @author Karl George Schaefer
 *
 */
class AutoCompleteFocusAdapter extends FocusAdapter {

}
