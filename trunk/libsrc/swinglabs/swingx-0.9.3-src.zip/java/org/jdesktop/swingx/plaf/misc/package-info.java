/**
 * A package to collect miscellaneous UI delegates.
 */
package org.jdesktop.swingx.plaf.misc;

