//$Id: QuerySecondPass.java 9019 2006-01-11 18:50:33Z epbernard $
package org.hibernate.cfg;

/**
 * Bind query
 *
 * @author Emmanuel Bernard
 */
public interface QuerySecondPass extends SecondPass {
}
